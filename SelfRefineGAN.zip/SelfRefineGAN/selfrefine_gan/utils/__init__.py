"""Image and visualization utilities."""
