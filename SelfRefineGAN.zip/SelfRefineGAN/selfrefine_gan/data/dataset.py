"""Build the TensorFlow paired-image dataset."""

from __future__ import annotations

from functools import partial
from typing import Iterable

import tensorflow as tf

from selfrefine_gan.data.preprocessing import load_pair

AUTOTUNE = tf.data.AUTOTUNE


def make_dataset(
    low_images: Iterable[str],
    gt_images: Iterable[str],
    *,
    image_height: int,
    image_width: int,
    batch_size: int,
    apply_resize: bool,
    drop_remainder: bool = True,
    shuffle: bool = False,
    seed: int = 42,
) -> tf.data.Dataset:
    low_images = list(low_images)
    gt_images = list(gt_images)

    if len(low_images) != len(gt_images):
        raise ValueError("Input and GT path lists must have the same length.")
    if not low_images:
        raise ValueError("Cannot construct a dataset from an empty image list.")

    dataset = tf.data.Dataset.from_tensor_slices((low_images, gt_images))
    if shuffle:
        dataset = dataset.shuffle(
            buffer_size=len(low_images),
            seed=seed,
            reshuffle_each_iteration=True,
        )

    dataset = dataset.map(
        partial(
            load_pair,
            apply_resize=apply_resize,
            image_height=image_height,
            image_width=image_width,
        ),
        num_parallel_calls=AUTOTUNE,
    )
    dataset = dataset.batch(batch_size, drop_remainder=drop_remainder)
    return dataset.prefetch(AUTOTUNE)
