"""TensorFlow image reading, paired resizing, and paired random cropping."""

from __future__ import annotations

import tensorflow as tf


def read_image(image_path: tf.Tensor) -> tf.Tensor:
    image_bytes = tf.io.read_file(image_path)
    image = tf.image.decode_image(
        image_bytes,
        channels=3,
        expand_animations=False,
    )
    image.set_shape([None, None, 3])
    return tf.cast(image, tf.float32) / 255.0


def resize_pair(
    low_image: tf.Tensor,
    gt_image: tf.Tensor,
    image_height: int,
    image_width: int,
) -> tuple[tf.Tensor, tf.Tensor]:
    low_image = tf.image.resize(low_image, [image_height, image_width])
    gt_image = tf.image.resize(gt_image, [image_height, image_width])
    low_image.set_shape([image_height, image_width, 3])
    gt_image.set_shape([image_height, image_width, 3])
    return low_image, gt_image


def random_crop_pair(
    low_image: tf.Tensor,
    gt_image: tf.Tensor,
    image_height: int,
    image_width: int,
) -> tuple[tf.Tensor, tf.Tensor]:
    low_shape = tf.shape(low_image)[:2]

    crop_width = tf.random.uniform(
        shape=(),
        maxval=low_shape[1] - image_width + 1,
        dtype=tf.int32,
    )
    crop_height = tf.random.uniform(
        shape=(),
        maxval=low_shape[0] - image_height + 1,
        dtype=tf.int32,
    )

    low_crop = low_image[
        crop_height : crop_height + image_height,
        crop_width : crop_width + image_width,
    ]
    gt_crop = gt_image[
        crop_height : crop_height + image_height,
        crop_width : crop_width + image_width,
    ]
    low_crop.set_shape([image_height, image_width, 3])
    gt_crop.set_shape([image_height, image_width, 3])
    return low_crop, gt_crop


def load_pair(
    low_path: tf.Tensor,
    gt_path: tf.Tensor,
    *,
    apply_resize: bool,
    image_height: int,
    image_width: int,
) -> tuple[tf.Tensor, tf.Tensor]:
    low_image = read_image(low_path)
    gt_image = read_image(gt_path)
    if apply_resize:
        return resize_pair(low_image, gt_image, image_height, image_width)
    return random_crop_pair(low_image, gt_image, image_height, image_width)
