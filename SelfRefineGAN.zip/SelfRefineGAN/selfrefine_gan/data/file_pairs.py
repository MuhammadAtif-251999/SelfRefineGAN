"""Discover and split paired low-light and ground-truth image paths."""

from __future__ import annotations

from pathlib import Path

SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp"}


def _sorted_images(folder: str | Path) -> list[str]:
    directory = Path(folder)
    if not directory.is_dir():
        raise FileNotFoundError(f"Image directory not found: {directory}")

    return [
        str(path)
        for path in sorted(directory.iterdir())
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS
    ]


def discover_paired_images(root: str | Path) -> tuple[list[str], list[str]]:
    root = Path(root)
    low_images = _sorted_images(root / "input")
    gt_images = _sorted_images(root / "gt")

    if not low_images or not gt_images:
        raise FileNotFoundError(
            f"No paired images found under {root / 'input'} and {root / 'gt'}."
        )
    if len(low_images) != len(gt_images):
        raise ValueError(
            "Different input and GT image counts: "
            f"{len(low_images)} versus {len(gt_images)}."
        )

    low_names = [Path(path).name for path in low_images]
    gt_names = [Path(path).name for path in gt_images]
    if low_names != gt_names:
        raise ValueError(
            "Input and GT filenames do not match after sorting. "
            "Use the same filenames in both folders."
        )
    return low_images, gt_images


def split_training_images(
    root: str | Path,
    max_train_images: int,
) -> tuple[list[str], list[str], list[str], list[str]]:
    """Use the first N sorted pairs for training, matching the notebook."""
    low_images, gt_images = discover_paired_images(root)
    return (
        low_images[:max_train_images],
        gt_images[:max_train_images],
        low_images[max_train_images:],
        gt_images[max_train_images:],
    )
